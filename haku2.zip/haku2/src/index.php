<!doctype html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<h1>gosssssssssqaaqaedfgsa</h1>
<?php
 
 echo "string";
?>
</body>
</html>